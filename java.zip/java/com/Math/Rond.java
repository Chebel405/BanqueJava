package com.Math;

public class Rond {
    public String figure;

    public void dessiner(){
        System.out.println("Je dessine");
    }

    //Constructor
    public Rond(String figure) {
        this.figure = figure;
    }
    // G S
    public String getFigure() {
        return figure;
    }

    public void setFigure(String figure) {
        this.figure = figure;
    }



    @Override
    public String toString() {
        return "Carre{" +
                "figure='" + figure + '\'' +
                '}';
    }
}
