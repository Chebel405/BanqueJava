package com.Math;

public class Main {
}
