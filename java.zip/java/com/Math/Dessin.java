package com.Math;

public interface Dessin {

    void dessiner();
}
