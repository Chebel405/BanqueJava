package com.Banque;

import java.util.ArrayList;
import java.util.List;

public class Client{
    private Integer id;
    private String nom;
    private String prenom;
 // private Date dateNaissance;
    private Boolean solde;

    List<Compte>listCompte = new ArrayList<>();

    public Client(Integer id, String nom, String prenom, /*Date dateNaissance,*/ Boolean solde) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
    //    this.dateNaissance = dateNaissance;
        this.solde = solde;
    }

    public Client() {

    }


    public String getNom() {
        return this.nom;
    }
    public void setNom(String nom) {this.nom = nom;}
    public String getPrenom() {return this.prenom;}
    public void setPrenom(String prenom) {this.prenom = prenom;}

   /* public Date getDateNaissance() {return this.dateNaissance;}
    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }*/

    public Boolean getSolde() {return this.solde;}
    public void setSolde(Boolean solde) {this.solde = solde;}

    List<String> listClient = new ArrayList<String>();



    public void deposer(String value) {
        System.out.println( value + " euros ont été déposés");
    }


    public void retirer(String somme){
        System.out.println( somme + " euros ont été retirés");
    }

}
/*Rechercher un compte, client*/