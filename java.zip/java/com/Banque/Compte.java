package com.Banque;

import com.beans.Personne;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Compte extends Agence{
    private Integer id;
    private Integer numeroCompte;
    private Date dateCreation;
    private String type;

    private Integer somme;

    private Client client;
    //attribut du client
   // String id = ";"



    private Integer getId() {
        return id;
    }

    private void setId(Integer id) {
        this.id = id;
    }

    private Integer getNumeroCompte() {
        return numeroCompte;
    }

    private void setNumeroCompte(Integer numeroCompte) {
        this.numeroCompte = numeroCompte;
    }

    private Date getDateCreation() {
        return dateCreation;
    }

    private void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    private Integer getSomme() {
        return somme;
    }

    private void setSomme(Integer somme) {
        this.somme = somme;
    }

    private String getType() {
        return type;
    }

    private void setType(String type) {
        this.type = type;
    }

    List<Client> listClient = new ArrayList<>();




    public void deposer() {
        System.out.println(" Le compte n° " + numeroCompte + " a reçu " + somme + " euros" );
    }


    public void retirer() {
        System.out.println("Le compte n° " + numeroCompte + " a retiré " + somme + " euros" );
    }

}
