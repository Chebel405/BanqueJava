package com.Banque;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Client> listClient = new ArrayList<>();
        List<Compte> listCompte = new ArrayList<>();

        Client client = new Client();
        Compte compte = new Compte();

        int choix=1;
        switch (choix) {
            case 1:
                if (choix == 1){
                    System.out.println("Inscrire votre numéros de comptes");
                    String numeroCompte = scanner.next();
                    break;

                }
            case 2:
                if (choix == 2) {
                    System.out.println("Ajout d'argent:  ");
                    String somme = scanner.next();
                    client.deposer(somme);
                    break;
                }
            case 3:
                System.out.println("Retirer l'argent ");
                String somme = scanner.next();
                client.retirer(somme);
                break;
            case 4:
                System.out.println("Afficher votre compte: ");

       /*System.out.println("Veuillez entrer la somme que vous souhaitez déposer : ");
        String value = scanner.next();
        client.deposer(value);*/

       // System.out.println("Veuillez entrer la somme que vous souhaitez retirer : ");
      /*  String somme = scanner.next();
        client.retirer(somme);*/

      /*  System.out.println("Vueillez inscrire votre prenom : " );
        String prenom = scanner.next();
        client.retirer(value);*/
       // client.listClient.add(prenom);

        }

    }

}
