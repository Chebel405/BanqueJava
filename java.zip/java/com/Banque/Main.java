package com.Banque;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Client> listClient = new ArrayList<>();
        List<Compte> listCompte = new ArrayList<>();

      /*  Scanner scanner = new Scanner(System.in);

        try{
            System.out.println("Veuilez entrez un nombre :");
            int zero = scanner.nextInt();
            if(args.length == 0){
                throw new Exception("Impossible");
            }

        }catch(Exception e ){
            System.out.println("Erreur" + args);
        }*/
        //Client client = new Client(1, "Chebel", "Albert", true );
      //  List<Client>listClient = new ArrayList<>();
       /* Compte compte = new Compte();
        compte.deposer();
        compte.retirer();*/

        Client client = new Client();
        System.out.println("Veuillez entrer la somme que vous souhaitez déposer : ");
        String value = scanner.next();
        client.deposer(value);

        System.out.println("Veuillez entrer la somme que vous souhaitez retirer : ");
        String somme = scanner.next();
        client.retirer(somme);

        System.out.println("Vueillez inscrire votre prenom : " );
        String prenom = scanner.next();
        client.retirer(value);
       // client.listClient.add(prenom);

        Compte compte = new Compte();









    }

}
