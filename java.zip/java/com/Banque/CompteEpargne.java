package com.Banque;

public class CompteEpargne extends Compte{
    private Integer id;

    public CompteEpargne(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
