package com.Banque;

public class CompteRemunerer extends Compte{
    private Integer id;

    public CompteRemunerer(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
