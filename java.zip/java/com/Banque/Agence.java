package com.Banque;

import java.util.ArrayList;
import java.util.List;

public class Agence {

    List<Client>listClient = new ArrayList<>();




}

