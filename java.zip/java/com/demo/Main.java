package com.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.Integer.parseInt;

public class Main {
    public static void main(String[] args) {

        //variables
        String message = "bonjour";
        int nombre = 14;
        String nombre2 = "25";


        //Cast
        int resu = nombre + parseInt(nombre2);


        //console.log
        System.out.println(message + nombre);


        //Tableau de taille 5
        double[] tableau = new double[5];
        tableau[0] = 4;
        tableau[1] = 45;
        tableau[2] = 77;
        tableau[4] = 78;


    System.out.println(tableau[3]);

        //Listes avec valeurs par defauts

        List<String> maListe = new ArrayList<String>(Arrays.asList("demo", "why not", "fait chaud"));

        //Ajout d'une liste
        maListe.add("test");
        System.out.println(maListe);

        //for
        for (int i = 0; i < maListe.size(); i++) {
            System.out.println(maListe.get(i));
        }

        //for pour Array
        for (int i = 0; i < tableau.length; i++) {
            System.out.println(tableau[i]);
        }
        //foreach
        for (String item: maListe
             ) {
            System.out.println(item);
        }


        //while tableau
        int i =0;
        while(i < tableau.length){
            System.out.println(tableau[i]);
            i++;
        }


        //While sur la liste
        i = 0;
        while (i < maListe.size()){
            System.out.println(maListe.get(i));
            i++;
        }

        //do-while instruction et execution

        i = 0;
        do {
            System.out.println("bonjour toi");

        } while (i != 0);

        for (double item: tableau
        ) {
            if(item == 45) continue;
            if(item == 77) break;
            //parcours
            System.out.println(item);
        }

    }
}
