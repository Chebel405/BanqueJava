package com.Interfaces;

public interface Pilotable extends PilotableParent {

    static final int ALTITUDE_SECURITE = 100;
    long getPuissance();
    void setPuissance(long puissanceCible);
    long getAltitude();
    void rentrerTrainAtterissage();
    void sortirTrainAtterissage();
    void inclinerVolets(long angle);
    void setPositionManche(long position);



}
