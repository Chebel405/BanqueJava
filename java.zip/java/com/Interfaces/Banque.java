package com.Interfaces;

public interface Banque {

}
