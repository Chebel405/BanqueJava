package com.Interfaces;

public interface Aquatique {


    void nage();
}
