package com.Interfaces;

public interface PilotableParent  {


    void decolle (Pilotable pilo);



}
