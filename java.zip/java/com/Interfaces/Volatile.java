package com.Interfaces;

import com.Animaux.Animal;

public interface Volatile {

    void voler();
}
