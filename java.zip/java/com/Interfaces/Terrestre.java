package com.Interfaces;

import com.Animaux.Animal;

import java.util.ArrayList;
import java.util.List;

public interface Terrestre  {
    List<Animal> animaux = new ArrayList<>();


}
