package com.Mer;

public abstract class Mamifere{

    public abstract void respirerSousEau();
    public abstract void respirerHorsDeEau();
    public abstract void Marcher();
    public abstract void Nager();

}
