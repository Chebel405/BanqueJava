package com.Mer;

public interface Dauphin {

}
