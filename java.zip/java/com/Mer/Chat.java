package com.Mer;

public interface Chat {
}
