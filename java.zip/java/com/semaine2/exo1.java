package com.semaine2;

import com.sun.source.tree.TryTree;

import java.util.Scanner;

public class exo1 {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        try{
            System.out.println("Veuilez entrez un nombre :");
            int zero = scanner.nextInt();
          if(args.length == 0){
              throw new Exception("Impossible");
          }

        }catch(Exception e ){
            System.out.println("Erreur" + args);
        }

    }
}
/**/