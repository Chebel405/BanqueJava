package com.Animaux;

public class Voliere extends Conteneur{
}
