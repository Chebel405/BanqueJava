package com.Animaux;

public class Main {

    public static void main(String[] args){

        Chat c1 = new Chat("Felix");
        Zoo z = new Zoo();
      /*  z.ajouterAnimal(c1);
        z.faireParlerTousLesAnimaux();*/
    }
}
