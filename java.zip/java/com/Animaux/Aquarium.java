package com.Animaux;

public class Aquarium extends Conteneur {

}
