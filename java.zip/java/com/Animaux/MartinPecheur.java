package com.Animaux;

import com.Interfaces.Aquatique;

public class MartinPecheur implements Aquatique {
    public String nom;
    public String prenom;
    public boolean nage;



    public void nage(){
        this.nage=true;

    }



    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public boolean isNage() {
        return nage;
    }

    public void setNage(boolean nage) {
        this.nage = nage;
    }
}
