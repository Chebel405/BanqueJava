package com.Animaux;

public class Chat extends Animal{
    public String nom;

    //constructor
    public Chat(String nom) {
        this.nom = nom;
    }


    //Setter Getter
    public String getNom() {
        return nom;
    }
    public void setNom() {
        this.nom = nom;
    }

    @Override
    public void parler(){
        System.out.println("Miaou");
    }

    @Override
    public void allerLitiere(){
        System.out.println("JE vais défequer");
    }

    @Override
    public void manger(){
        System.out.println("J'ai faim");
    }
    @Override
    public void dormir(){
        System.out.println("Je vais me coucher");
    }


}
