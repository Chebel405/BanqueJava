package com.Animaux;


    public abstract class Animal{
        public abstract void parler();
        public abstract void manger();
        public abstract void dormir();
        public abstract void allerLitiere();

    }

