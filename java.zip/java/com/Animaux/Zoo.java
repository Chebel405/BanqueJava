package com.Animaux;

import java.util.ArrayList;
import java.util.List;

public class Zoo {
 List<Conteneur> listConteneurs = new ArrayList<>();

 public void afficherConteneur(){
     //
     for (Conteneur c: listConteneurs){
         if(c instanceof Cage){
             //tester la nature de l'objet intantiation
             Cage cage  = (Cage) c;
         }
     };
 }

 /*public void faireParlerTousLesAnimaux(){
     for (Animal a : animaux){
         a.parler();
     }*/
 }

