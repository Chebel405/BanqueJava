package com.Animaux;

public class Cage extends Conteneur{

}
