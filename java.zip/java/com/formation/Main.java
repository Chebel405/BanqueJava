package com.formation;


import com.beans.exo1.exo1;
import com.beans.exo1.exo2;

public class Main {
    public static void main(String[] args) {
    exo1 exercice1 = new exo1();
    exercice1.usersList();

    exo2 exercice2 = new exo2();


    }
}

