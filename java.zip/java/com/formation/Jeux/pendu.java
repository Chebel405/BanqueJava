package com.formation.Jeux;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class pendu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> listeMotUtilisateur = new ArrayList<String>();// [b,o,n,j,o,u,r] mot decomposer en lettre
        List<String> listeMotCacher = new ArrayList<String>();// liste de lettre remplacer par tiret  [ _ _ _ _ _ _ _ ]

        System.out.println("Veuillez choisir un nombre de vie?");
        int vie = scanner.nextInt();
        boolean isFound = false;
        boolean isWin = false;
        boolean gagne = false;

        System.out.println("Saisir un mot?");
        String mot = scanner.next();
        // le nbre de lettre pour la longueur du mot

        for (int i = 0; i < mot.length(); i++) {
            String lettre = String.valueOf(mot.charAt(i)); // transforme la lettre en string
            listeMotUtilisateur.add(lettre);//ajouter les lettre
            listeMotCacher.add("_");//ajouter "_" correspondant aux lettres
        }
        System.out.println(listeMotUtilisateur);//afficher les lettres en liste
        System.out.println(listeMotCacher);//afficher la liste de lettre cacher en liste


        // lenght chaine de caractere // size pour liste
        while(vie != 0){
            System.out.println("Veuillez ajouter une lettre");
            String lettre = scanner.next();

            isFound = false;

            for (int i = 0; i < listeMotUtilisateur.size(); i++) {
                //Recuperer l'element de la liste
                if(listeMotUtilisateur.get(i).equals(lettre)){
                    listeMotCacher.set(i, lettre);
                    isFound = true;
                }
            }
            if(!isFound ){
                vie--;
            }
            if (!isFound){
                for (int i = 0; i < listeMotCacher.size(); i++) {

                    if(listeMotCacher.get(i).equals("_") == false){
                        isWin = true;
                        break;
                    }
                }
            }

          /**  if(isWin){
                break;
            }*/
            System.out.println(listeMotCacher);

        }

        if(vie == 0){
            System.out.println("Perdu");
        }else{
            System.out.println("Gagné");
        }


    }
}
