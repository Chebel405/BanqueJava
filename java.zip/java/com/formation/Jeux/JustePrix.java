package com.formation.Jeux;

import java.util.*;

public class JustePrix {
    public static void main(String[] args) {
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(mpVie(),0, 30*1000);

    }
    static TimerTask mpVie () {

        Random random = new Random();
        int choixRandom = random.nextInt(30 + 1) + 1;
        System.out.println(choixRandom);

        int vie = 30;

        while ( vie > 0) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Saisir un nombre ?");
            int nombre = scanner.nextInt();

            if(nombre != choixRandom) {
                if (nombre < choixRandom) {
                    System.out.println("Plus");
                } else if (nombre > choixRandom) {

                    System.out.println("Moins");
                }
                vie--;
                System.out.println(vie);
            }else {
                System.out.println("Gagner");

            }


        }
        return null;
    }


}


