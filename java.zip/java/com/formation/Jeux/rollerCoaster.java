/**package com.formation.Jeux;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class rollerCoaster {
    
        List<Integer> tours = new ArrayList<Integer>();
        int[] places = new int[] {};

        Scanner scanner = new Scanner(System.in);
        int profits;
        int places;
        int groupe = 10;
        int prix;
        int file;
        int tour = 10;


    for(int index = 0; index < places; index++) {
        places[index] =
    }
        while(file <= 10){
            if(places != 0){
                file[i] = places += 1;


            }else if (places > 10){
                tour = tour += 1;
            }
        }
    }
*/
        

