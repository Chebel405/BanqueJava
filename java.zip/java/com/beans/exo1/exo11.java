/*package com.formation.exo1;*/

/**import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class exo11 {
    public static void main(String[] args) {


        List<Double> argents = new ArrayList<>(Arrays.asList(500.00, 200.00, 20.00, 10.00, 5.00, 2.00, 0.50, 0.02));
        Scanner scanner = new Scanner(System.in);

        System.out.println("Saisir un nombre: ");
        Double value = scanner.nextDouble();
       

         double ChoixArgent;


         for (double item: argents) {
                    if(item >= 1000)
                        System.out.println("Billet de " + argents[item];
                        System.out.println("Billet de " + argents[item];
                        System.out.println("Billet de " + argents[item];
                        System.out.println("Billet de " + argents[item];
                        System.out.println("Billet de " + argents[item];
                        continue;
                    if(item < 0)
                        break;
                    //parcours
                    System.out.println(item);
                }

















    }
}
*/