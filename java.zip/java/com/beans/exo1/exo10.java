package com.beans.exo1;

public class exo10 {

}
