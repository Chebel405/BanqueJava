/**package com.formation.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo9 {
    public static void main(String[] args) {

        List<String> star = new ArrayList<String>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Saisir un nombre: ");
        int value = Integer.parseInt(scanner.next());


        for (int i = 0; i <= value; i++) {
            String etoile = "*";
            System.out.println(etoile.repeat(i));
            for (int j = value; j <= value; j--) {
                System.out.println(etoile.repeat(j));
            }
        }
    }
}
*/