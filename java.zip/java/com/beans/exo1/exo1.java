package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo1 {
    //Contructor
    public void Exo1(){}

    public void usersList(){
        List<String> maListe = new ArrayList<String>();

        //Créer une boucle
        int i =0;
        while (i < 5) {

            //Demander une valeur
            Scanner scanner = new Scanner(System.in);
            System.out.println("Veuillez renseignez un nom de moins de 5 caractères:");

            String value = scanner.next();

            //Vérifier si celle ci respecte la contrainte
            if (value.length() > 5){
                System.out.println("hey ca depaase là");
                continue;
            };

            maListe.add(value);
            i++;
        }
        System.out.println(maListe);

    }
}
