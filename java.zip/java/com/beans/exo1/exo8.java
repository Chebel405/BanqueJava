package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo8 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Saisir un nombre: ");

        int value = Integer.parseInt(scanner.next());
        for (int i = 0; i <= value; i++) {
            String etoile = "*";

            System.out.println(etoile.repeat(i));
        }
    }
}

