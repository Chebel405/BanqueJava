package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Buzz {
    public static void main(String[] args) {

        List<Integer> Nombres = new ArrayList<Integer>();
        Scanner scanner = new Scanner(System.in);


        System.out.println("Veuillez saisir un nombre ?");
        int nombre = scanner.nextInt();

        if  (((nombre % 3) == 0) && (nombre % 5 ) == 0) {
            System.out.println("FIZZBUZZ");

        } else if ((nombre % 5) == 0) {
            System.out.println("BUZZ");

        } else if ((nombre % 3) == 0) {
            System.out.println("FIZZ");

        }else
            System.out.println(nombre);

    }


}
