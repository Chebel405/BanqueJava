package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo6 {
    public static void main(String[] args) {

       // List<Integer> operation = new ArrayList<Integer>();
        int resultat;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Veuillez inscrire un nombre: ");
        int nombre1 = scanner.nextInt();

        System.out.println("choisir l'opérateur: ");
        String operateur = scanner.next();

        System.out.println("Veuillez inscrire un nombre: ");
        int nombre2 = scanner.nextInt();

        if(operateur.equals("/")  ){
             resultat = nombre1 / nombre2;
        }
        else if (operateur.equals("+")  ){
            resultat = nombre1 + nombre2;
        }
        else if (operateur.equals("-")  ){
            resultat = nombre1 - nombre2;
        }
        else{
            resultat = nombre1 * nombre2;
        }
        System.out.println(resultat);
    }
}
