package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo3 {
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);

        System.out.println("Veuillez saisir votre le calcul ?");


        System.out.println( "Entrez le chiffre 1" );
        int nombre = scanner.nextInt();


        System.out.println( "Entrez le chiffre 2" );
        int nombre2 = scanner.nextInt();


        int resultat = (nombre + nombre2);
        System.out.println("Le résultat est de :" + resultat);

    }
}

