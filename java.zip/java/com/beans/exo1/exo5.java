package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo5 {
    public static void main(String[] args) {

        List<Integer> note = new ArrayList<Integer>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Veuillez saisir votre la note ?");

        int notes = scanner.nextInt();
        if (notes > 18) {
            System.out.println("Excellent travail");
        } else if (notes > 15) {
            System.out.println("Bien");
        } else if (notes > 11) {
            System.out.println("Peut mieux faire");
        } else if (notes > 5) {
            System.out.println("insuffisant");
        } else if (notes >= 0) {
            System.out.println("Cata");
        }

    }
}





