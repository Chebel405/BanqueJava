package com.beans.exo1;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo2 {
    public static void main(String[] args) {

        List<String> name = new ArrayList<String>();


        Scanner scanner = new Scanner(System.in);

        System.out.println("Veuillez saisir votre nom ?");
        String value = scanner.next();

        System.out.println("Bienvenue" + value);
    }
}
