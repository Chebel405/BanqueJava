package com.beans.exo1;

import java.util.*;

public class exo4 {
    public static void main(String[] args) {

        List<Integer> ordreNombre = new ArrayList<Integer>();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Veuillez saisir 3 nombres ?");
        int nombre1 = scanner.nextInt();
        ordreNombre.add(nombre1);
        System.out.println("Veuillez saisir 2e nombres ?");
        int nombre2 = scanner.nextInt();
        ordreNombre.add(nombre2);
        System.out.println("Veuillez saisir 3é nombres ?");
        int nombre3 = scanner.nextInt();
        ordreNombre.add(nombre3);

        Collections.sort(ordreNombre);
        System.out.println(ordreNombre.get(ordreNombre.size() - 1));




    }
}
