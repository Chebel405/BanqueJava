package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo7 {
    public static void main(String[] args) {

        List<Integer> maListe = new ArrayList<Integer>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Saisir un nombre: ");
        int nombre = scanner.nextInt();

        int j = 0;

        for (int i = 1; i < nombre + 1; i++) {
            maListe.add(j + i );
            System.out.println( +  i );
        }

        System.out.println(maListe);
    }
}
