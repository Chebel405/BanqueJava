package com.beans.exo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exo03 {
    public static void main(String[] args) {

        List<Double> profit = new ArrayList<Double>();

        Scanner scanner = new Scanner(System.in);


        System.out.println("Veuillez saisir le prix e fabrication?");
        double prixProfit = scanner.nextDouble();

        System.out.println("Veuillez saisir le prix de vente :");
        double prixVente = scanner.nextDouble();

        if(prixVente > prixProfit) {
            double montant = prixVente - prixProfit;
            System.out.println("Profit = " + montant);
        }
            else if (prixProfit > prixVente){
                double montant = prixProfit - prixVente;
                System.out.println("Perte = " + montant);
            }else {
            System.out.println("ni l'un ni l'autre");
        }
        scanner.close();
    }

}

