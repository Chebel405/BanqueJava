package com.beans.exo1;

import java.util.*;


    public class exo13 {
        public static void main(String[] args) {



            List<Integer> ordreNombre = new ArrayList<Integer>(Arrays.asList(3,67,4,34,2));
            Scanner scanner = new Scanner(System.in);

            System.out.println("Veuillez trier la liste de numeros dans ordre croissant");
            for (int i = 0; i < ordreNombre.size(); i++) {
                Collections.sort(ordreNombre);
                System.out.println(ordreNombre.get(i));
            }




        }
    }

