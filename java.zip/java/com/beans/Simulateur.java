package com.beans;

import com.Interfaces.Pilotable;

public class Simulateur implements Pilotable {
    protected Boolean trainAtterissage;
    protected long puissance;
    protected long altitude;
    protected long angleVolets;
    protected long positionManche;

    @Override
    public long getPuissance() {
        return this.puissance;
    }
    @Override
    public void setPuissance(long puissanceCible) {
        this.puissance = puissanceCible;
    }
    @Override
    public long getAltitude() {
        return this.altitude;
    }

    @Override
    public void rentrerTrainAtterissage() {
        this.trainAtterissage=true;
    }
    @Override
    public void sortirTrainAtterissage() {
        this.trainAtterissage=false;
    }
    @Override
    public void inclinerVolets(long angle) {
        this.angleVolets=angle;
    }
    @Override
    public void setPositionManche(long position) {
        this.positionManche = position;
    }

    @Override
    public void decolle(Pilotable pilo) {

    }
}


