package com.beans;


    public class Personne{
        protected String prenom;
        protected int age;
        protected int taille;
        protected String genre;

        public Personne(String prenom, int age, int taille, String genre) {

            this.prenom = prenom;
            this.age = age;
            this.taille = taille;
            this.genre = genre;

        }

        public String getPrenom() {
            return prenom;
        }

        public void setPrenom(String prenom){
            this.prenom = prenom;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public int getTaille() {
            return taille;
        }

        public void setTaille(int taille) {
            this.taille = taille;
        }

        public String getGenre() {
            return genre;
        }

        public void setGenre(String genre) {
            this.genre = genre;
        }

        @Override
        public String toString () {
            return "prenom:" + prenom + "age:" + age + "genre :" + genre + "taille :" + taille;
        }
    }
