package com.beans;

import com.Interfaces.Pilotable;
import com.beans.Pilote;

public class Pilote {
    private String nom;
    protected String prenom;


    public void decolle(Pilotable pilo){
        pilo.setPositionManche(3);
    }
// 3 entite
    //agence bancaire avec client qui a un compte
    //3 types de comptes bancaires
    //3 types de clients
        //Cleint simple == retirer l'argent et deposer et Afficher son solde Pourra faire des virements bancaires
        //client de l agence
    //le conseiller peut faire tt et ouvrir des compte fermer des comptes
    //Directeur fait tt et ouvirr des agences et fermer des agences

    //Faire un login et un mot de passe pour afficher (methode)
}