package com.beans;

public class Conseiller extends Personne{

    protected String role;
    protected int numero;

    public Conseiller(String prenom, int age, int taille, String genre, String role, int numero) {
        super(prenom, age, taille, genre);
        this.role = role;
        this.numero = numero;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    @Override
    public String toString () {
        return "prenom:" + prenom + "age:" + age + "genre:" + genre + "taille:" + taille + "role:" + role + "numero:" + numero;
    }
}
