package com.beans;

public class Directeur extends Personne {

    protected int telephone;
    protected int salaire;

    public Directeur(String prenom, int age, int taille, String genre, int telephone, int salaire) {
        super(prenom, age, taille, genre);
        this.telephone = telephone;
        this.salaire = salaire;
    }

    public int getTelephone() {
        return telephone;
    }

    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }

    public int getSalaire() {
        return salaire;
    }

    public void setSalaire(int salaire) {
        this.salaire = salaire;
    }
    @Override
    public String toString () {
        return "prenom:" + prenom + "age:" + age + "genre:" + genre + "taille:" + taille + "telephonne:" + telephone + "salaire:" + salaire;
    }
}
