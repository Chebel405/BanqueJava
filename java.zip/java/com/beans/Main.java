package com.beans;

import com.Interfaces.Pilotable;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args){

       Personne personne = new Personne("Bob",19,183,"Homme");
       Directeur directeur = new Directeur("Boby",20,145,"Homme",062151251, 1520);
       Conseiller conseiller = new Conseiller("Elise",35,150,"femme","secretaire", 54);

       directeur.setPrenom("Jean");
       conseiller.setPrenom("Dylan");

       directeur.toString();
       personne.toString();
       conseiller.toString();

        List<Personne> maListe = new ArrayList<Personne>();
        maListe.add(directeur);
        maListe.add(conseiller);
        maListe.add(personne);

        Simulateur simulateur = new Simulateur();
        simulateur.setPuissance(10);
        System.out.println(simulateur.getPuissance());


        Pilote pilote = new Pilote();
        pilote.decolle(simulateur);



        Pilotable pilotable = new Simulateur();


    }
}
