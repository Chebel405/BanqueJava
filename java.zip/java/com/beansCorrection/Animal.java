package com.beansCorrection;

public interface Animal {

    void miauler();
    
}