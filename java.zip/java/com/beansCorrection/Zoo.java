package com.beansCorrection;



public class Zoo {

    public Animal animal;

    public Zoo(Animal animal) {
        this.animal = animal;
    }

}

